# StockDancer 📈💃

바탕화면 한켠에 띄워두는 **투명창 주식 마스코트**. 지정한 종목의 시세를 주기적으로 받아,
**전일 대비 등락**에 따라 캐릭터가 다른 춤을 춥니다. (한국 관례대로 **이득=빨강, 손해=파랑**)
등락률이 클수록 춤이 과감해지고, 때리면 **효과음 5종**(펑/딱/빡/뿅/퉁) 중 랜덤으로 납니다.

Godot 4.6 · 절차적 드로잉(외부 이미지 에셋 0개) · 데이터는 네이버 실시간 시세.

## 실행

`StockDancer.exe` **더블클릭**. 설치·의존성 없이 단일 실행 파일입니다.
기본은 **종목 미지정** — 처음 켜면 검색창이 뜹니다. 종목명(예: `삼성전자`)이나 6자리 코드로 검색해 고르면 됩니다.

## 조작

- **"종목" 버튼(우상단)**: 종목명 또는 6자리 코드로 검색 → 후보 클릭 → 적용. 선택은 저장돼 다음 실행에 자동 적용. 코드를 모르면 **"네이버에서 찾기 ↗"** 로 브라우저 검색.
- **캐릭터 클릭**: 화풀이 때리기 — 찌그러지고 튕기며 비명 + 효과음 + 카운터(잠시 뒤 자동으로 사라짐).
- **드래그**: 창 이동.
- **"✕" 버튼 / ESC**: 종료.

## 춤 상태 (전일 종가 대비)

| 상태 | 조건 | 모습 |
|---|---|---|
| 이득 | 전일 대비 상승(+) | 빨강, 팔 들고 방방 |
| 손해 | 전일 대비 하락(−) | 파랑, 시무룩 + 눈물 |
| 보합 | 등락 0 | 회색, 잔잔한 흔들림 |
| 장마감 | 장 마감/휴장 | 눈 감고 `Zzz` (색·기분은 등락 그대로 유지) |

강도는 당일 등락률로 정해집니다(±7%에서 최대). 클수록 점프·기울기·좌우스텝·눈물이 커집니다.
장중엔 4초마다, **장 마감/휴장 시엔 5분마다** 갱신 — 값이 안 변하므로 요청을 최소화합니다.

## 데이터 소스

무키(無key) 네이버 실시간 엔드포인트:
- 시세: `GET https://polling.finance.naver.com/api/realtime/domestic/stock/{코드}`
- 종목 검색: `GET https://m.stock.naver.com/front-api/search/autoComplete?target=stock&query={이름}`

데스크탑 앱이라 브라우저 CORS 제약이 없어 프록시가 필요 없습니다.
**비공식 엔드포인트**라 예고 없이 바뀔 수 있습니다 — 안정성/분봉이 필요하면
한국투자증권 KIS Open API(공식·무료·계좌+앱키)로 승격 검토.

## 소스에서 실행 / 다시 빌드

- 실행: Godot 4.6으로 프로젝트 열고 F5, 또는 `godot --path .`
- 배포용 exe(약 39MB)는 **불필요 모듈을 뺀 커스텀 템플릿**으로 만듭니다(표준 템플릿은 104MB). 요약:
  1. Godot 4.6.3 소스에서 size 최적화 컴파일 — `scons platform=windows target=template_release production=yes optimize=size lto=full disable_3d=yes d3d12=no` + 안 쓰는 모듈 다수 `module_*_enabled=no` (3D물리/Jolt·gltf·오디오코덱·이미지포맷·멀티플레이 등). **유지**: gdscript·mbedtls(HTTPS)·freetype·text_server_adv(한글/시스템폰트 폴백)·svg·opengl.
  2. `export_presets.cfg`의 `custom_template/release`를 그 템플릿으로 지정 → `godot --headless --path . --export-release "Windows Desktop" build/StockDancer.exe`
- 종목 선택은 **exe와 같은 폴더의 `settings.cfg`**에 저장됩니다(지우면 초기화). 에디터로 실행할 땐 `user://`. 폴링 주기는 [main.gd](main.gd)의 `POLL_OPEN`·`POLL_CLOSED`로 조절.
